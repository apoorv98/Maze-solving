run the demo file for complete execution of code.
You may also require arduino based bot for hardware implementation.